/**
* jumps the browser to the page selectd in the select box
*
* @param object selObj a select form element
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function autoselect(selObj){
	 if(selObj.options[selObj.selectedIndex].value.length > 0){
		eval("document.location='"+selObj.options[selObj.selectedIndex].value+"'");
	 }
  }


/**
* Erases form content even if the form came pre-filled (unlike reset button)
*
* @param int theForm the form to clear
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function clearForm(theForm){
  $(theForm).find('input[type="text"], input[type="radio"], input[type="checkbox"], select').val('');
}


/**
* toggles an inline div on or off
*
* @param string form element id
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function toggleInlineDiv(element_id) {
  $('#' + element_id).toggle('blind', {}, 100);
}


  /**
  * toggles an image back & forth like a plus/minus or twistdown triangle
  *
  * @param image_id
  * @author peet sasaki <peet@strongsquare.net>
  * @access public
  * @returns
  */
  function toggleImage(image_id) {
     the_image = $(image_id);
     if(the_image.src == window.toggle_on_src){
        the_image.src = window.toggle_off_src;
     } else {
        the_image.src = window.toggle_on_src;
     }
  }


/**
*  
*
* @param
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function initToggleImageSrc(on_src,off_src) {
  window.toggle_on_src = on_src;
  window.toggle_off_src = off_src;
}



/**
* requires date format: mm/dd/yyyy
*
* @param string date
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function valiDate(string){
   dateRegexp = new RegExp('^[0-9]{2,2}/[0-9]{2,2}/[0-9]{4,4}$');
   if(!dateRegexp.test(string)){
      return false;
   } else {
      return true;
   }
}

/**
* requires date format: [m]m/[d]d/[yy]yy
*
* @param string date
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function valiDateLoose(string){
   dateRegexp = new RegExp('^[0-9]{1,2}/[0-9]{1,2}/[0-9]{2,4}$');
   if(!dateRegexp.test(string)){
      return false;
   } else {
      return true;
   }
}

/**
* left pads integer to 2 places ('01')
*
* @param int num
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function padDayMonth(num){
   num_string = num.toString();
   if(num_string.length == 1){
      var string = "0"+num;
   } else {
      var string = num;
   }
   return string;
}

/**
* left pads two digit year to 4 digit (assumes century 2000)
*
* @param int num
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function padYear(num){
   if(num.length == 2){
      var string = "20"+num;
   } else {
      var string = num;
   }
   return string;
}

/**
* converts loose date format to strict(er):
*  1/1/04 --> 01/01/2004
*
* @param string form element id
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function dateFix(obj){
   var string = obj.value;
   if(string.length == 0 ){
      return true;
   }
   if(!valiDateLoose(string)){
      alert('Please enter dates in the format mm/dd/yyyy.');
      return false;
   }
   var parts = string.split("/");
   obj.value = padDayMonth(parts[0]) +"/"+ padDayMonth(parts[1]) +"/"+ padYear(parts[2]);
}



/**
* removes non-digits, adds decimal
* @param form element object obj
* @author peet sasaki <peet@strongsquare.net>
* @access public
*/
function dollarFix(obj) {
   var string = obj.value;
   var reg = new RegExp('[^0-9]',"g");
   var clean = string.replace(reg,'');
   var len = clean.length;
   obj.value = clean.substr(0,(len-2)) + '.' + clean.substr((len-2));
   return true;
}


/**
*
*
* @param
* @author peet sasaki <peet@strongsquare.net>
* @access public
* @return 
*/
function validateOneCheckboxIsChecked(box_id,form_id) {
   one_checked = false;
   for(i=0; i<document.forms[form_id].elements.length; i++){
	  if(document.forms[form_id].elements[i].name == box_id && document.forms[form_id].elements[i].checked){
		 one_checked = true;
	  }
   }   
   return one_checked;
}


/**
*
*
* @param submit button object
* @author peet sasaki <peet@strongsquare.net>
* @access public
* @return  bool
*/
function disableSubmit(submitbutton) {
   submitbutton.value = 'Please Wait...';
   submitbutton.disabled = true;
   return true;
}


/**
 *
 */
function toggleCheckAll(selector) {
   if($(selector + ':checked').length > 0){
     $(selector).prop('checked', false);
   } else {
     $(selector).prop('checked', true);
   }
}



/**
*
* @param submit button object
* @author peet sasaki <peet@strongsquare.net>
* @access public
* @return  bool
*/
function submitOnce(submitbutton) {
   if(submitbutton.form.wassubmitted){
      //alert('You pressed submit already');
      return false;
   } else {
      submitbutton.value = 'Please Wait...';
      submitbutton.form.wassubmitted = true;
      return true;
   }
}

function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}

//-->