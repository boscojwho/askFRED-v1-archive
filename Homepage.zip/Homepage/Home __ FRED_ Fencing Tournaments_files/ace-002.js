
/**
 * Plugin $.ace
 * A jQuery plugin providing some all purpose front end behavior utilities 
 */
(function($) {  
  var opts;
  var methods = {
    init: function(options){
      opts = $.extend({}, $.fn.ace.defaults, options);    
      return this.each(function(){
        // TODO
      });
    },  
    
    /**
     * Centers the target in the viewport both vertically and horizontally.
     */
    viewCenter: function(){
      return this.each(function(){
        $(this).offset({
          left: ($(window).width() / 2 - $(this).width() / 2),
          top: ($(window).height() / 2 - $(this).height() / 2)
        });
      });
    },
    
    /**
     * Expands the target to fill the full document dimensions
     */
    fillDoc: function(){
      return this.each(function(){
        $(this).width($(document).width());
        $(this).height($(document).height());
      });
    },
    
    /**
     * If the string msg is longer than len, returns the msg truncated and with an ellipsis...
     * If msg is shorter or equal to len, returns msg unmolested.
     */
    truncate: function(msg, len) {
      return msg.length <= len ? msg : msg.substr(0, len - 3) + '...';
        
    },
    
    /**
     * Inserts success or error messages into the DOM 
     * @param {Object} options with props:
     * <ul>
     * <li>content: the ajax response text. May be JSON or html. if JSON, it's expected to
     *   have a 'message' property.
     * <li>css_class: css class to apply to the message container
     * <li>fade_delay: milliseconds to leave the message visible
     * <li>fade_speed: milliseconds speed to fade out the message
     * </ul>
     */
    showMsg: function(options) {
      return this.each(function(){
        var o = $.extend({
          css_class: 'fail',
          fade_delay: 10000, // ten seconds
          fade_speed: 500,
          content: 'There was an error.'
        }, options);
        try { var json = $.parseJSON(o.content); } catch(e) { }
        var msg = typeof json == 'object' ? json.message : o.content;
        $(this).html(msg)
            .show()
            .attr('class', o.css_class) // erase earlier class styling while setting ours 
            .delay(o.fade_delay)
            .fadeOut(o.fade_speed);        
      });
    },
    
    /**
     * Captures arbitrary form submissions and runs them via ajax. 
     * @param {Object} options with properties:
     * <ul>
     * <li>error: optional callback run on ajax error, taking the same params as the JQuery ajax error callback
     * <li>success: optional callback run on ajax success, taking the same params as the JQuery ajax success callback
     * </ul>
     */
    ajaxForm: function(options) {
      var o = $.extend({
        error: function(){ alert('There was an error. Please try again.'); },
        success: function(){ alert('Your submission was successful.'); },
        wait: function(){}
      }, options);
      return this.each(function(){
        $(this).submit(function(ev){
          ev.preventDefault();
          o.wait();
          var data = $(this).serialize();
          $.ajax({
            url: $(this).attr('action'), 
            type: 'POST',
            data: data,
            error: function(jqXHR, textStatus, errorThrown) {
              o.error(jqXHR, textStatus, errorThrown);
            },
            success: function(data, textStatus, jqXHR) {
              o.success(data, textStatus, jqXHR);
            }
          });
        });
      });
    }
  };

  $.fn.ace = function(method) {
    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist' );
    }
  };
  
  $.fn.ace.defaults = { };
})(jQuery);


/**
 * Plugin $.acetoggler
 * A jQuery plugin to standardize toggling open/closed areas of the dom. Handles
 * toggling the target, and changing the image src and text of the toggler link. 
 */
(function($) {  
  var methods = {
    init: function(options){
      var opts = $.extend({}, $.fn.acetoggler.defaults, options);
      return this.each(function(){
        // retain a reference to the toggle container for use in handlers
        var container = $(this);
        var toggler = container.find(opts.toggler).first();
        var target = container.find(opts.target).first();
        
        // initialize some state
        container.data('acetoggler-state', { state: opts.initially });
        if (opts.initially == 'open') {
          target.show();
          toggler.find(opts.text).text(opts.openText);
          toggler.find(opts.img).attr('src', opts.openImgSrc);          
        } else {
          target.hide();
          toggler.find(opts.text).text(opts.closedText);
          toggler.find(opts.img).attr('src', opts.closedImgSrc);          
        }

        // bind to click event
        $(this).find(opts.toggler).first().on('click', function(ev){
          ev.preventDefault();
          var s = container.data('acetoggler-state');
          target.toggle(opts.effect, {}, opts.duration);
          toggler.find(opts.text).text(s.state == 'open' ? opts.closedText : opts.openText);
          toggler.find(opts.img).attr('src', s.state == 'open' ? opts.closedImgSrc : opts.openImgSrc);          
          s.state = s.state == 'open' ? 'closed' : 'open';
        });
      });
    }
  };

  $.fn.acetoggler = function(method) {
    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist' );
    }
  };
  
  $.fn.acetoggler.defaults = {
    toggler: '.toggler-link',  // selector
    target: '.toggler-target',  // selector
    text: 'span', // selector
    img: 'img', // selector
    closedImgSrc: '',  // string URL
    openImgSrc: '',  // string URL
    closedText: 'more...',
    openText: 'less...',
    effect: 'blind',
    duration: 100,
    initially: 'closed'  // 'closed' or 'open'
  };
})(jQuery);


