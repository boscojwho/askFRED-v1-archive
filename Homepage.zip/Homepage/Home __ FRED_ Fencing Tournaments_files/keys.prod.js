/**
 * A file containing only keys for various services used via JS.
 * Enables us to have one file for prod and one for demo, separate from 
 * code that uses the key(s). Of course, since this file is included in 
 * regular web pages in the clear, only keys that may safely be made public
 * should be kept here!
 * 
 * Vars are declared in the global scope, so namespaced like Google closure does.
 * 
 * These are the PROD keys.
 */
net = {};
net.askfred = {};
net.askfred.stripe = {};
net.askfred.stripe.publickey = 'pk_QtDYVM9D48yS0QuBo1JFxFRyn3HNY';

