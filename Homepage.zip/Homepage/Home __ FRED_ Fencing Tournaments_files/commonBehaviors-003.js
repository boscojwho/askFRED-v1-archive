$(function(){
  $('.datepicker').datepicker();
  $(document).tooltip();
  // titles will be picked up by tooltip().
  $(".prereg_link").attr('title', 'Preregister');
  $(".who_coming_link").attr('title', 'Who is coming?');
  $(".more_info_link").attr('title', 'More tournament info');
  $(".more_clinic_info_link").attr('title', 'More clinic info');
  $(".email_org_link").attr('title', 'Email the organizers');
  $(".manage_link").attr('title', 'Manage this tournament');
  $(".event-list-toggler").attr('title', 'Click to see events');
  $(".map-link").attr('title', 'Go go Google Maps for directions, etc.');
});

