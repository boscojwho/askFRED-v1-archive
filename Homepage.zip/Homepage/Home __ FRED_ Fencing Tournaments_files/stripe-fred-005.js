$(function () {
  // Abort if we're not on a payment page.
  if (! $('#card-element').length) {
    return;
  }

  // net.askfred.stripe.publickey is defined in keys.(demo|prod).js
  var stripe = Stripe(net.askfred.stripe.publickey);
  var paymentForm = $('#stripe-form');
  var submitBtn = paymentForm.find('#submit-btn');
  var errors = $('#card-errors');
  var elements = stripe.elements();
  var card = elements.create('card', {
    'hidePostalCode': true,
    'iconStyle': 'solid',
  });

  card.mount('#card-element');

  card.addEventListener('change', function (event) {
    if (event.error) {
      showError(event.error.message);
    } else {
      showError('');
    }
  });

  var validate = function () {
    if (!$('#agree').is(':checked')) {
      showError('Please read the terms of service and check the box.');
      return false;
    }
    if (!$('#statement').is(':checked')) {
      showError('Please check the box to acknowledge the business name on your statement.');
      return false;
    }
    return true;
  };

  var showError = function (msg) {
    errors.text(msg || '');
  };

  var createToken = function() {
    var extraData = {
      'name': $('input[name=bill_first_name]').val() + ' ' + $('input[name=bill_last_name]').val(),
      'address_line1': $('input[name=bill_address]').val(),
      'address_city': $('input[name=bill_city]').val(),
      'address_state': $('input[name=bill_state]').val(),
      'address_zip': $('input[name=bill_zip]').val(),
      'address_country': $('select[name=bill_country]').val()
    };

    stripe.createToken(card, extraData).then(function(result) {
      if (result.error) {
        showError(result.error.message);
        submitBtn.text("Submit Payment.")
      } else {
        // Insert the token into the form so it gets submitted to the server
        paymentForm.find('#stripe-token').val(result.token.id);
        // And finally submit.
        paymentForm.get(0).submit();
      }
    });
  };

  paymentForm.submit(function (ev) {
    ev.preventDefault();
    if (!validate()) {
      return false;
    }

    // Disable the submit button to prevent repeated clicks
    submitBtn.prop('disabled', true)
      .data('orig-text', submitBtn.text())
      .text('Please wait...');

    createToken();
  });

  // To help ensure the payment form is not submitted by browsers without JS
  // enabled (which would prevent calling Stripe), it is hidden at first and
  // must be shown via JS.
  paymentForm.show();
});
